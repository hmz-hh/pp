// vaydns-server is the server end of a DNS tunnel.
//
// Usage:
//
//	vaydns-server -gen-key [-privkey-file PRIVKEYFILE] [-pubkey-file PUBKEYFILE]
//	vaydns-server -udp ADDR [-privkey PRIVKEY|-privkey-file PRIVKEYFILE] [-fallback FALLBACKADDR] -domain DOMAIN -upstream UPSTREAMADDR
//
// Example:
//
//	vaydns-server -gen-key -privkey-file server.key -pubkey-file server.pub
//	vaydns-server -udp :53 -privkey-file server.key -domain t.example.com -upstream 127.0.0.1:8000
//
// With fallback for non-DNS traffic:
//
//	vaydns-server -udp :53 -privkey-file server.key -fallback 127.0.0.1:8888 -domain t.example.com -upstream 127.0.0.1:8000
//
// To generate a persistent server private key, first run with the -gen-key
// option. By default the generated private and public keys are printed to
// standard output. To save them to files instead, use the -privkey-file and
// -pubkey-file options.
//
//	vaydns-server -gen-key
//	vaydns-server -gen-key -privkey-file server.key -pubkey-file server.pub
//
// You can give the server's private key as a file or as a hex string.
//
//	-privkey-file server.key
//	-privkey 0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef
//
// The -udp option controls the address that will listen for incoming DNS
// queries.
//
// The -mtu option controls the maximum size of response UDP payloads.
// Queries that do not advertise requester support for responses of at least
// this size at least this size will be responded to with a FORMERR. The default
// value is maxUDPPayload.
//
// The -fallback option specifies a UDP address (host:port). If an incoming
// packet is not a valid DNS message, it will be forwarded to this address.
// This acts as a simple UDP proxy for non-DNS traffic, allowing another
// service to run on the same port.
//
// The -domain option specifies the root of the DNS zone reserved for the
// tunnel. See README for instructions on setting it up.
//
// The -upstream option specifies the TCP address to which incoming tunnelled
// streams will be forwarded.
package main

import (
	"bytes"
	"context"
	"encoding/base32"
	"encoding/binary"
	"errors"
	"flag"
	"fmt"
	"io"
	"net"
	"os"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	log "github.com/sirupsen/logrus"

	"github.com/jellydator/ttlcache/v3"
	"github.com/net2share/vaydns/dns"
	"github.com/net2share/vaydns/noise"
	"github.com/net2share/vaydns/turbotunnel"
	"github.com/xtaci/kcp-go/v5"
	"github.com/xtaci/smux"
)

const (
	defaultIdleTimeout = 10 * time.Second
	defaultKeepAlive   = 2 * time.Second
	// Bound the pre-smux handshake so half-open KCP sessions cannot linger
	// indefinitely and consume server resources.
	defaultHandshakeTimeout = 15 * time.Second

	// How to set the TTL field in Answer resource records.
	responseTTL = 60

	// How long we may wait for downstream data before sending an empty
	// response. If another query comes in while we are waiting, we'll send
	// an empty response anyway and restart the delay timer for the next
	// response.
	//
	// This number should be less than 2 seconds, which in 2019 was reported
	// to be the query timeout of the Quad9 DoH server.
	// https://dnsencryption.info/imc19-doe.html Section 4.2, Finding 2.4
	maxResponseDelay = 1 * time.Second

	// How long to wait for a TCP connection to upstream to be established.
	upstreamDialTimeout = 30 * time.Second

	// How long a fallback session can be idle before being torn down.
	fallbackIdleTimeout = 2 * time.Minute
)

var (
	// We don't send UDP payloads larger than this, in an attempt to avoid
	// network-layer fragmentation. 1280 is the minimum IPv6 MTU, 40 bytes
	// is the size of an IPv6 header (though without any extension headers),
	// and 8 bytes is the size of a UDP header.
	//
	// Control this value with the -mtu command-line option.
	//
	// https://dnsflagday.net/2020/#message-size-considerations
	// "An EDNS buffer size of 1232 bytes will avoid fragmentation on nearly
	// all current networks."
	//
	// On 2020-04-19, the Quad9 resolver was seen to have a UDP payload size
	// of 1232. Cloudflare's was 1452, and Google's was 4096.
	maxUDPPayload = 1280 - 40 - 8

	// recordType is the DNS record type used for downstream data encoding.
	// Set from the -record-type command-line flag.
	recordType uint16 = dns.RRTypeTXT
)

// base32Encoding is a base32 encoding without padding.
var base32Encoding = base32.StdEncoding.WithPadding(base32.NoPadding)

// ServerStats tracks query processing statistics.
type ServerStats struct {
	total   uint64
	success uint64
}

func (s *ServerStats) incTotal()   { atomic.AddUint64(&s.total, 1) }
func (s *ServerStats) incSuccess() { atomic.AddUint64(&s.success, 1) }
func (s *ServerStats) log() {
	total := atomic.LoadUint64(&s.total)
	success := atomic.LoadUint64(&s.success)
	log.Debugf("stats | total: %d | success: %d", total, success)
}

// generateKeypair generates a private key and the corresponding public key. If
// privkeyFilename and pubkeyFilename are respectively empty, it prints the
// corresponding key to standard output; otherwise it saves the key to the given
// file name. The private key is saved with mode 0400 and the public key is
// saved with 0666 (before umask). In case of any error, it attempts to delete
// any files it has created before returning.
func generateKeypair(privkeyFilename, pubkeyFilename string) (err error) {
	// Filenames to delete in case of error (avoid leaving partially written
	// files).
	var toDelete []string
	defer func() {
		for _, filename := range toDelete {
			fmt.Fprintf(os.Stderr, "deleting partially written file %s\n", filename)
			if closeErr := os.Remove(filename); closeErr != nil {
				fmt.Fprintf(os.Stderr, "cannot remove %s: %v\n", filename, closeErr)
				if err == nil {
					err = closeErr
				}
			}
		}
	}()

	privkey, err := noise.GeneratePrivkey()
	if err != nil {
		return err
	}
	pubkey := noise.PubkeyFromPrivkey(privkey)

	if privkeyFilename != "" {
		// Save the privkey to a file.
		f, err := os.OpenFile(privkeyFilename, os.O_RDWR|os.O_CREATE, 0400)
		if err != nil {
			return err
		}
		toDelete = append(toDelete, privkeyFilename)
		err = noise.WriteKey(f, privkey)
		if err2 := f.Close(); err == nil {
			err = err2
		}
		if err != nil {
			return err
		}
	}

	if pubkeyFilename != "" {
		// Save the pubkey to a file.
		f, err := os.Create(pubkeyFilename)
		if err != nil {
			return err
		}
		toDelete = append(toDelete, pubkeyFilename)
		err = noise.WriteKey(f, pubkey)
		if err2 := f.Close(); err == nil {
			err = err2
		}
		if err != nil {
			return err
		}
	}

	// All good, allow the written files to remain.
	toDelete = nil

	if privkeyFilename != "" {
		fmt.Printf("privkey written to %s\n", privkeyFilename)
	} else {
		fmt.Printf("privkey %x\n", privkey)
	}
	if pubkeyFilename != "" {
		fmt.Printf("pubkey  written to %s\n", pubkeyFilename)
	} else {
		fmt.Printf("pubkey  %x\n", pubkey)
	}

	return nil
}

// readKeyFromFile reads a key from a named file.
func readKeyFromFile(filename string) ([]byte, error) {
	f, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	return noise.ReadKey(f)
}

// handleStream bidirectionally connects a client stream with a TCP socket
// addressed by upstream.
func handleStream(stream *smux.Stream, upstream string, conv uint32) error {
	dialer := net.Dialer{
		Timeout: upstreamDialTimeout,
	}
	upstreamConn, err := dialer.Dial("tcp", upstream)
	if err != nil {
		return fmt.Errorf("stream %08x:%d connect upstream: %v", conv, stream.ID(), err)
	}
	defer upstreamConn.Close()
	upstreamTCPConn := upstreamConn.(*net.TCPConn)

	var wg sync.WaitGroup
	wg.Add(2)
	go func() {
		defer wg.Done()
		_, err := io.Copy(stream, upstreamTCPConn)
		if err == io.EOF {
			// smux Stream.Write may return io.EOF.
			err = nil
		}
		if err != nil && !errors.Is(err, io.ErrClosedPipe) {
			log.Warnf("stream %08x:%d copy stream←upstream: %v", conv, stream.ID(), err)
		}
		upstreamTCPConn.CloseRead()
		stream.Close()
	}()
	go func() {
		defer wg.Done()
		_, err := io.Copy(upstreamTCPConn, stream)
		if err == io.EOF {
			// smux Stream.WriteTo may return io.EOF.
			err = nil
		}
		if err != nil && !errors.Is(err, io.ErrClosedPipe) {
			log.Warnf("stream %08x:%d copy upstream←stream: %v", conv, stream.ID(), err)
		}
		upstreamTCPConn.CloseWrite()
	}()
	wg.Wait()

	return nil
}

// acceptStreams wraps a KCP session in a Noise channel and an smux.Session,
// then awaits smux streams. It passes each stream to handleStream.
func acceptStreams(conn *kcp.UDPSession, privkey []byte, upstream string, idleTimeout time.Duration, keepAlive time.Duration) error {
	// Put a Noise channel on top of the KCP conn.
	rw, err := serverNoiseHandshake(conn, privkey, defaultHandshakeTimeout)
	if err != nil {
		return err
	}

	// Put an smux session on top of the encrypted Noise channel.
	smuxConfig := smux.DefaultConfig()
	smuxConfig.Version = 2
	smuxConfig.KeepAliveInterval = keepAlive
	smuxConfig.KeepAliveTimeout = idleTimeout
	smuxConfig.MaxStreamBuffer = 1 * 1024 * 1024 // default is 65536
	sess, err := smux.Server(rw, smuxConfig)
	if err != nil {
		return err
	}
	defer sess.Close()

	for {
		stream, err := sess.AcceptStream()
		if err != nil {
			if err, ok := err.(net.Error); ok && err.Temporary() {
				continue
			}
			return err
		}
		log.Infof("stream %08x:%d ready", conn.GetConv(), stream.ID())
		go func() {
			defer func() {
				log.Debugf("stream %08x:%d closed", conn.GetConv(), stream.ID())
				stream.Close()
			}()
			err := handleStream(stream, upstream, conn.GetConv())
			if err != nil {
				log.Warnf("stream %08x:%d handleStream: %v", conn.GetConv(), stream.ID(), err)
			}
		}()
	}
}

// serverNoiseHandshake performs the server-side Noise handshake with a deadline.
// This prevents half-open KCP sessions from hanging forever before smux starts.
func serverNoiseHandshake(conn *kcp.UDPSession, privkey []byte, timeout time.Duration) (io.ReadWriteCloser, error) {
	conn.SetDeadline(time.Now().Add(timeout))
	rw, err := noise.NewServer(conn, privkey)
	conn.SetDeadline(time.Time{}) // clear deadline after the handshake
	if err != nil {
		return nil, fmt.Errorf("noise handshake: %v", err)
	}
	return rw, nil
}

// acceptSessions listens for incoming KCP connections and passes them to
// acceptStreams.
func acceptSessions(ln *kcp.Listener, privkey []byte, mtu int, upstream string, idleTimeout time.Duration, keepAlive time.Duration, kcpWindowSize int) error {
	for {
		conn, err := ln.AcceptKCP()
		if err != nil {
			if err, ok := err.(net.Error); ok && err.Temporary() {
				continue
			}
			return err
		}
		log.Infof("session %08x ready", conn.GetConv())
		// Permit coalescing the payloads of consecutive sends.
		conn.SetStreamMode(true)
		// Disable the dynamic congestion window (limit only by the
		// maximum of local and remote static windows).
		conn.SetNoDelay(
			0, // default nodelay
			0, // default interval
			0, // default resend
			1, // nc=1 => congestion window off
		)
		conn.SetWindowSize(kcpWindowSize, kcpWindowSize)
		if rc := conn.SetMtu(mtu); !rc {
			panic(rc)
		}
		go func() {
			defer func() {
				log.Debugf("session %08x closed", conn.GetConv())
				conn.Close()
			}()
			err := acceptStreams(conn, privkey, upstream, idleTimeout, keepAlive)
			if err != nil && !errors.Is(err, io.ErrClosedPipe) {
				log.Warnf("session %08x accept streams: %v", conn.GetConv(), err)
			}
		}()
	}
}

// nextPacket reads the next length-prefixed packet from r using the VayDNS
// wire format. It returns io.EOF only when there were 0 bytes remaining to
// read from r. It returns io.ErrUnexpectedEOF when EOF occurs in the middle
// of an encoded packet.
func nextPacket(r *bytes.Reader) ([]byte, error) {
	eof := func(err error) error {
		if err == io.EOF {
			err = io.ErrUnexpectedEOF
		}
		return err
	}

	prefix, err := r.ReadByte()
	if err != nil {
		return nil, err
	}
	p := make([]byte, int(prefix))
	_, err = io.ReadFull(r, p)
	return p, eof(err)
}

// nextPacketDnstt reads the next packet from r using the original dnstt wire
// format with padding awareness. A prefix byte >= 224 indicates padding: the
// value (prefix - 224) gives the number of padding bytes that follow and are
// discarded. A prefix byte < 224 is a data length prefix. This handles both
// data packets (3 bytes padding) and poll packets (8 bytes padding).
func nextPacketDnstt(r *bytes.Reader) ([]byte, error) {
	eof := func(err error) error {
		if err == io.EOF {
			err = io.ErrUnexpectedEOF
		}
		return err
	}

	for {
		prefix, err := r.ReadByte()
		if err != nil {
			return nil, err
		}
		if prefix >= 224 {
			paddingLen := int64(prefix - 224)
			if _, err := io.CopyN(io.Discard, r, paddingLen); err != nil {
				return nil, eof(err)
			}
		} else {
			p := make([]byte, int(prefix))
			_, err = io.ReadFull(r, p)
			return p, eof(err)
		}
	}
}

// responseFor constructs a response dns.Message that is appropriate for query.
// Along with the dns.Message, it returns the query's decoded data payload. If
// the returned dns.Message is nil, it means that there should be no response to
// this query. If the returned dns.Message has an Rcode() of dns.RcodeNoError,
// the message is a candidate for for carrying downstream data in a TXT record.
func responseFor(query *dns.Message, domains []dns.Name) (*dns.Message, []byte, dns.Name) {
	responsePayloadSize := uint16(maxUDPPayload)
	if int(responsePayloadSize) != maxUDPPayload {
		responsePayloadSize = 0xffff
	}

	resp := &dns.Message{
		ID:       query.ID,
		Flags:    0x8000, // QR = 1, RCODE = no error
		Question: query.Question,
	}

	if query.Flags&0x8000 != 0 {
		// QR != 0, this is not a query. Don't even send a response.	
		return nil, nil, nil
	}

	// Check for EDNS(0) support. Include our own OPT RR only if we receive
	// one from the requester.
	// https://tools.ietf.org/html/rfc6891#section-6.1.1
	// "Lack of presence of an OPT record in a request MUST be taken as an
	// indication that the requester does not implement any part of this
	// specification and that the responder MUST NOT include an OPT record
	// in its response."
	payloadSize := 0
	for _, rr := range query.Additional {
		if rr.Type != dns.RRTypeOPT {
			continue
		}
		if len(resp.Additional) != 0 {
			// https://tools.ietf.org/html/rfc6891#section-6.1.1
			// "If a query message with more than one OPT RR is
			// received, a FORMERR (RCODE=1) MUST be returned."		
			resp.Flags |= dns.RcodeFormatError
			log.Debugf("FORMERR: more than one OPT RR")
			return resp, nil, nil
		}
		resp.Additional = append(resp.Additional, dns.RR{
			Name:  dns.Name{},
			Type:  dns.RRTypeOPT,
			Class: responsePayloadSize, // responder's UDP payload size
			TTL:   0,
			Data:  []byte{},
		})
		additional := &resp.Additional[0]

		version := (rr.TTL >> 16) & 0xff
		if version != 0 {
			// https://tools.ietf.org/html/rfc6891#section-6.1.1
			// "If a responder does not implement the VERSION level
			// of the request, then it MUST respond with
			// RCODE=BADVERS."		
			resp.Flags |= dns.ExtendedRcodeBadVers & 0xf
			additional.TTL = (dns.ExtendedRcodeBadVers >> 4) << 24
			log.Debugf("BADVERS: EDNS version %d != 0", version)
			return resp, nil, nil
		}
		payloadSize = int(rr.Class)
	}
	if payloadSize < 512 {
		// https://tools.ietf.org/html/rfc6891#section-6.1.1 "Values
		// lower than 512 MUST be treated as equal to 512."
		payloadSize = 512
	}
	// We will return RcodeFormatError if payloadSize is too small, but
	// first, check the name in order to set the AA bit properly.
		
	// There must be exactly one question.
	if len(query.Question) != 1 {
		resp.Flags |= dns.RcodeFormatError
		log.Debugf("FORMERR: too few or too many questions (%d)", len(query.Question))
		return resp, nil, nil
	}
	question := query.Question[0]

	// LOOP THROUGH ALL CONFIGURED DOMAINS TO FIND A MATCH
	var prefix [][]byte
	var matchedDomain dns.Name
	var ok bool

	// Check the name to see if it ends in our chosen domain, and extract
	// all that comes before the domain if it does. If it does not, we will
	// return RcodeNameError below, but prefer to return RcodeFormatError
	// for payload size if that applies as well.
	for _, d := range domains {
		prefix, ok = question.Name.TrimSuffix(d)
		if ok {
			matchedDomain = d
			break
		}
	}

	if !ok {
		// Not a name we are authoritative for.
		resp.Flags |= dns.RcodeNameError
		log.Debugf("NXDOMAIN: not authoritative for %s", question.Name)
		return resp, nil, nil
	}
	
	resp.Flags |= 0x0400 // AA = 1

	if query.Opcode() != 0 {
		// We don't support OPCODE != QUERY.
		resp.Flags |= dns.RcodeNotImplemented
		log.Debugf("NOTIMPL: unrecognized OPCODE %d", query.Opcode())
		return resp, nil, nil
	}

	if question.Type != recordType {
		// We only support the configured QTYPE.
		resp.Flags |= dns.RcodeNameError
		// No log message here; it's common for recursive resolvers to
		// send NS or A queries when the client only asked for a TXT. I
		// suspect this is related to QNAME minimization, but I'm not
		// sure. https://tools.ietf.org/html/rfc7816		
		return resp, nil, nil
	}

	encoded := bytes.ToUpper(bytes.Join(prefix, nil))
	payload := make([]byte, base32Encoding.DecodedLen(len(encoded)))
	n, err := base32Encoding.Decode(payload, encoded)
	if err != nil {
		// Base32 error, make like the name doesn't exist.
		resp.Flags |= dns.RcodeNameError
		log.Debugf("NXDOMAIN: base32 decoding: %v", err)
		return resp, nil, nil
	}
	payload = payload[:n]

	// We require clients to support EDNS(0) with a minimum payload size;
	// otherwise we would have to set a small KCP MTU (only around 200
	// bytes). https://tools.ietf.org/html/rfc6891#section-7 "If there is a
	// problem with processing the OPT record itself, such as an option
	// value that is badly formatted or that includes out-of-range values, a
	// FORMERR MUST be returned."
	if payloadSize < maxUDPPayload {
		resp.Flags |= dns.RcodeFormatError
		log.Debugf("FORMERR: requester payload size %d is too small (minimum %d)", payloadSize, maxUDPPayload)
		return resp, nil, nil
	}

	return resp, payload, matchedDomain // RETURN THE MATCHED DOMAIN
}

// record represents a DNS message appropriate for a response to a previously
// received query, along with metadata necessary for sending the response.
// recvLoop sends instances of record to sendLoop via a channel. sendLoop
// receives instances of record and may fill in the message's Answer section
// before sending it.
type record struct {
	Resp     *dns.Message
	Addr     net.Addr
	ClientID turbotunnel.ClientID
	Domain   dns.Name
}

// --- Fallback NAT logic for non-DNS packets ---

// UDPAddrKey is a comparable struct that can be used as a map key to represent
// a net.UDPAddr. It's designed to be highly performant by avoiding allocations.
//
// A net.UDPAddr cannot be a map key directly because its IP field is a slice,
// and slices are not comparable in Go. We solve this by converting the IP
// slice to a fixed-size [16]byte array, which is comparable. A 16-byte
// array can hold both IPv4 and IPv6 addresses.
type UDPAddrKey struct {
	IP   [16]byte
	Port int
	Zone string // For IPv6 link-local addresses
}

// NewAddrKey converts a *net.UDPAddr into a comparable UDPAddrKey.
// This function is designed to be allocation-free.
func NewAddrKey(addr *net.UDPAddr) UDPAddrKey {
	var key UDPAddrKey
	// The IP field in UDPAddr is a slice. We copy its contents into a
	// fixed-size 16-byte array. The IP.To16() method ensures that the
	// IP is in a 16-byte format, suitable for both IPv4 and IPv6.
	// This copy is the key to making the struct comparable.
	copy(key.IP[:], addr.IP.To16())
	key.Port = addr.Port
	key.Zone = addr.Zone
	return key
}

// FallbackManager handles forwarding of non-DNS UDP packets using a TTL cache
// to manage client sessions.
type FallbackManager struct {
	sessions     *ttlcache.Cache[UDPAddrKey, net.PacketConn]
	mainConn     net.PacketConn
	fallbackAddr net.Addr
}

// NewFallbackManager creates a new manager for forwarding non-DNS packets.
func NewFallbackManager(mainConn net.PacketConn, fallbackAddr net.Addr) *FallbackManager {
	log.Infof("non-DNS packets will be forwarded to %s", fallbackAddr)

	cache := ttlcache.New(ttlcache.WithTTL[UDPAddrKey, net.PacketConn](fallbackIdleTimeout))
	cache.OnEviction(func(ctx context.Context, reason ttlcache.EvictionReason, i *ttlcache.Item[UDPAddrKey, net.PacketConn]) {
		// This function is called when a client session expires due to inactivity.
		// Closing the connection will cause the corresponding forwardReplies goroutine to exit.
		i.Value().Close()
	})

	// Start a goroutine to clean up expired items from the cache periodically.
	go cache.Start()

	return &FallbackManager{
		sessions:     cache,
		mainConn:     mainConn,
		fallbackAddr: fallbackAddr,
	}
}

// HandlePacket finds or creates a fallback session for the given client address
// and forwards the packet to the fallback server. Activity on a session (i.e.,
// a call to this function) refreshes its timeout.
func (m *FallbackManager) HandlePacket(packet []byte, clientAddr net.Addr) {
	clientKey := NewAddrKey(clientAddr.(*net.UDPAddr))

	// Get the session from the cache. This also refreshes the TTL.
	item := m.sessions.Get(clientKey)
	var proxyConn net.PacketConn

	if item == nil {
		// Session doesn't exist, create a new one.
		newConn, err := net.ListenPacket("udp", ":0")
		if err != nil {
			log.Errorf("failed to create fallback socket for %v: %v", clientKey, err)
			return
		}
		proxyConn = newConn // Use the new connection

		// Add the new session to the cache.
		// The TTL is set to the default defined in the cache constructor.
		m.sessions.Set(clientKey, newConn, ttlcache.DefaultTTL)
		log.Infof("created new fallback session for %s via %s", clientAddr.String(), newConn.LocalAddr())

		// Start a goroutine to forward replies for this new session.
		go m.forwardReplies(newConn, clientAddr)

	} else {
		// Session exists, use the existing connection.
		proxyConn = item.Value()
	}

	// Forward the client's packet to the fallback address.
	_, err := proxyConn.WriteTo(packet, m.fallbackAddr)
	if err != nil {
		log.Errorf("fallback write to %s for client %v failed: %v", m.fallbackAddr, clientKey, err)
	}
}

// forwardReplies reads from a session's proxy connection (which receives packets
// from the fallback server) and forwards them to the original client via the
// main server connection. This method runs in its own goroutine for each session
// and exits when the proxy connection is closed by the cache's eviction handler.
func (m *FallbackManager) forwardReplies(proxyConn net.PacketConn, clientAddr net.Addr) {
	defer log.Infof("ending fallback reply forwarder for %s", clientAddr.String())

	buf := make([]byte, 65535) // max UDP packet size
	for {
		n, _, err := proxyConn.ReadFrom(buf)
		if err != nil {
			// Error is expected when the connection is closed by the eviction handler.
			// net.ErrClosed is the specific error returned in this case.
			if !errors.Is(err, net.ErrClosed) {
				log.Errorf("fallback read from proxy conn for %s failed: %v", clientAddr, err)
			}
			return // Exit goroutine.
		}

		// Got a reply from the fallback server. Forward it to the original client.
		_, writeErr := m.mainConn.WriteTo(buf[:n], clientAddr)
		if writeErr != nil {
			log.Errorf("fallback write to client %s failed: %v", clientAddr, writeErr)
			// If we can't write to the client, we don't need to do anything special.
			// The session will eventually time out and be cleaned up if the client
			// stops sending packets.
		}
	}
}

// recvLoop repeatedly calls dnsConn.ReadFrom, extracts the packets contained in
// the incoming DNS queries, and puts them on ttConn's incoming queue. Whenever
// a query calls for a response, constructs a partial response and passes it to
// sendLoop over ch. Invalid DNS packets are passed to the FallbackManager.

func recvLoop(domains []dns.Name, dnsConn net.PacketConn, ttConn *turbotunnel.QueuePacketConn, ch chan<- *record, fallbackMgr *FallbackManager, stats *ServerStats, wireConfig turbotunnel.WireConfig) error {
	for {
		var buf [4096]byte
		n, addr, err := dnsConn.ReadFrom(buf[:])
		if err != nil {
			if err, ok := err.(net.Error); ok && err.Temporary() {
				log.Warnf("ReadFrom temporary error: %v", err)
				continue
			}
			return err
		}

		stats.incTotal()

		// Got a UDP packet. Try to parse it as a DNS message.
		query, err := dns.MessageFromWireFormat(buf[:n])
		if err != nil {
			if fallbackMgr != nil {
				// Packet is not a valid DNS message, forward it if fallback is configured.
				fallbackMgr.HandlePacket(buf[:n], addr)
			} else {
				log.Debugf("cannot parse DNS query from %s: %v", addr, err)
			}
			continue
		}

		resp, payload, matchedDomain := responseFor(&query, domains)
		//resp, payload := responseFor(&query, domain)
		// Extract the ClientID from the payload.
		var clientID turbotunnel.ClientID
		if len(payload) < wireConfig.ClientIDSize {
			// Payload is not long enough to contain a ClientID.
			if resp != nil && resp.Rcode() == dns.RcodeNoError {
				resp.Flags |= dns.RcodeNameError
				log.Debugf("NXDOMAIN: %d bytes are too short to contain a ClientID", len(payload))
			}
		} else {
			clientID = turbotunnel.ClientID(string(payload[:wireConfig.ClientIDSize]))
			payload = payload[wireConfig.ClientIDSize:]
			// Pull out the packets contained in the payload.
			r := bytes.NewReader(payload)
			for {
				var p []byte
				var err error
				if wireConfig.IsDnstt() {
					p, err = nextPacketDnstt(r)
				} else {
					p, err = nextPacket(r)
				}
				if err != nil {
					break
				}
				// Feed the incoming packet to KCP.
				ttConn.QueueIncoming(p, clientID)
			}
		}
		// If a response is called for, pass it to sendLoop via the channel.
		if resp != nil {
			if resp.Rcode() == dns.RcodeNoError {
				stats.incSuccess()
			}
			select {
			//case ch <- &record{resp, addr, clientID}:
			case ch <- &record{resp, addr, clientID, matchedDomain}:
			default:
			}
		}
	}
}

// encodeResponsePayload encodes the downstream payload into the DNS response
// Answer section using the record type from the query's Question.
func encodeResponsePayload(rec *record, data []byte, domain dns.Name) error {
	qtype := rec.Resp.Question[0].Type
	switch qtype {
	case dns.RRTypeA, dns.RRTypeAAAA:
		var chunks [][]byte
		if qtype == dns.RRTypeA {
			chunks = dns.EncodeRDataA(data)
		} else {
			chunks = dns.EncodeRDataAAAA(data)
		}
		rec.Resp.Answer = make([]dns.RR, len(chunks))
		for i, chunk := range chunks {
			rec.Resp.Answer[i] = dns.RR{
				Name:  rec.Resp.Question[0].Name,
				Type:  qtype,
				Class: rec.Resp.Question[0].Class,
				TTL:   responseTTL,
				Data:  chunk,
			}
		}
	case dns.RRTypeNULL:
		rec.Resp.Answer[0].Data = dns.EncodeRDataNULL(data)
	case dns.RRTypeCAA:
		rec.Resp.Answer[0].Data = dns.EncodeRDataCAA(data)
	case dns.RRTypeCNAME:
		rdata, err := dns.EncodeRDataCNAME(data, domain)
		if err != nil {
			return fmt.Errorf("EncodeRDataCNAME: %w", err)
		}
		rec.Resp.Answer[0].Data = rdata
	case dns.RRTypeNS:
		rdata, err := dns.EncodeRDataNS(data, domain)
		if err != nil {
			return fmt.Errorf("EncodeRDataNS: %w", err)
		}
		rec.Resp.Answer[0].Data = rdata
	case dns.RRTypeMX:
		rdata, err := dns.EncodeRDataMX(data, domain)
		if err != nil {
			return fmt.Errorf("EncodeRDataMX: %w", err)
		}
		rec.Resp.Answer[0].Data = rdata
	case dns.RRTypeSRV:
		rdata, err := dns.EncodeRDataSRV(data, domain)
		if err != nil {
			return fmt.Errorf("EncodeRDataSRV: %w", err)
		}
		rec.Resp.Answer[0].Data = rdata
	default:
		rec.Resp.Answer[0].Data = dns.EncodeRDataTXT(data)
	}
	return nil
}

// sendLoop repeatedly receives records from ch. Those that represent an error
// response, it sends on the network immediately. Those that represent a
// response capable of carrying data, it packs full of as many packets as will
// fit while keeping the total size under maxEncodedPayload, then sends it.
func sendLoop(dnsConn net.PacketConn, ttConn *turbotunnel.QueuePacketConn, ch <-chan *record, maxEncodedPayload int) error {
	var nextRec *record
	for {
		rec := nextRec
		nextRec = nil

		if rec == nil {
			var ok bool
			rec, ok = <-ch
			if !ok {
				break
			}
		}

		if rec.Resp.Rcode() == dns.RcodeNoError && len(rec.Resp.Question) == 1 {
			// If it's a non-error response, we can fill the Answer
			// section with downstream packets.

			// Any changes to how responses are built need to happen
			// also in computeMaxEncodedPayload.
			rec.Resp.Answer = []dns.RR{
				{
					Name:  rec.Resp.Question[0].Name,
					Type:  rec.Resp.Question[0].Type,
					Class: rec.Resp.Question[0].Class,
					TTL:   responseTTL,
					Data:  nil, // will be filled in below
				},
			}

			var payload bytes.Buffer
			limit := maxEncodedPayload
			// We loop and bundle as many packets from OutgoingQueue
			// into the response as will fit. Any packet that would
			// overflow the capacity of the DNS response, we stash
			// to be bundled into a future response.
			timer := time.NewTimer(maxResponseDelay)
			for {
				var p []byte
				unstash := ttConn.Unstash(rec.ClientID)
				outgoing := ttConn.OutgoingQueue(rec.ClientID)
				// Prioritize taking a packet first from the
				// stash, then from the outgoing queue, then
				// finally check for the expiration of the timer
				// or for a receive on ch (indicating a new
				// query that we must respond to).
				select {
				case p = <-unstash:
				default:
					select {
					case p = <-unstash:
					case p = <-outgoing:
					default:
						select {
						case p = <-unstash:
						case p = <-outgoing:
						case <-timer.C:
						case nextRec = <-ch:
						}
					}
				}
				// We wait for the first packet in a bundle
				// only. The second and later packets must be
				// immediately available or they will be omitted
				// from this bundle.
				timer.Reset(0)

				if len(p) == 0 {
					// timer expired or receive on ch, we
					// are done with this response.
					break
				}

				limit -= 2 + len(p)
				if payload.Len() == 0 {
					// No packet length check for the first
					// packet; if it's too large, we allow
					// it to be truncated and dropped by the
					// receiver.
				} else if limit < 0 {
					// Stash this packet to send in the next
					// response.
					ttConn.Stash(p, rec.ClientID)
					break
				}
				if int(uint16(len(p))) != len(p) {
					panic(len(p))
				}
				binary.Write(&payload, binary.BigEndian, uint16(len(p)))
				payload.Write(p)
			}
			timer.Stop()

			// PASS THE SPECIFIC DOMAIN FOR THIS QUERY TO ENCODER
			
			if err := encodeResponsePayload(rec, payload.Bytes(),  rec.Domain); err != nil {
				log.Errorf("encode response: %v", err)
				continue
			}
		}

		buf, err := rec.Resp.WireFormat()
		if err != nil {
			log.Errorf("resp WireFormat: %v", err)
			continue
		}
		// Truncate if necessary.
		// https://tools.ietf.org/html/rfc1035#section-4.1.1
		if len(buf) > maxUDPPayload {
			log.Warnf("truncating response of %d bytes to max of %d", len(buf), maxUDPPayload)
			buf = buf[:maxUDPPayload]
			buf[2] |= 0x02 // TC = 1
		}

		// Now we actually send the message as a UDP packet.
		_, err = dnsConn.WriteTo(buf, rec.Addr)
		if err != nil {
			if errors.Is(err, net.ErrClosed) {
				return err
			}
			if err, ok := err.(net.Error); ok && err.Temporary() {
				log.Warnf("WriteTo temporary error: %v", err)
			} else {
				log.Warnf("WriteTo error: %v", err)
			}
			continue
		}
	}
	return nil
}

// computeMaxEncodedPayload computes the maximum amount of downstream single-RR
// payload that keeps the overall response size less than maxUDPPayload, in the
// worst case when the response answers a query that has a maximum-length name
// in its Question section. Returns 0 in the case that no amount of data makes
// the overall response size small enough.
//
// This function needs to be kept in sync with sendLoop with regard to how it
// builds candidate responses.
func computeMaxEncodedPayload(limit int, encode func([]byte) []byte) int {
	// 64+64+64+62 octets, needs to be base32-decodable.
	maxLengthName, err := dns.NewName([][]byte{
		[]byte("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"),
		[]byte("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"),
		[]byte("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"),
		[]byte("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"),
	})
	if err != nil {
		panic(err)
	}
	{
		// Compute the encoded length of maxLengthName and that its
		// length is actually at the maximum of 255 octets.
		n := 0
		for _, label := range maxLengthName {
			n += len(label) + 1
		}
		n += 1 // For the terminating null label.
		if n != 255 {
			panic(fmt.Sprintf("max-length name is %d octets, should be %d %s", n, 255, maxLengthName))
		}
	}

	queryLimit := uint16(limit)
	if int(queryLimit) != limit {
		queryLimit = 0xffff
	}
	query := &dns.Message{
		Question: []dns.Question{
			{
				Name:  maxLengthName,
				Type:  recordType,
				Class: dns.ClassIN,
			},
		},
		// EDNS(0)
		Additional: []dns.RR{
			{
				Name:  dns.Name{},
				Type:  dns.RRTypeOPT,
				Class: queryLimit, // requester's UDP payload size
				TTL:   0,          // extended RCODE and flags
				Data:  []byte{},
			},
		},
	}
	resp, _, _ := responseFor(query, []dns.Name{})
	// As in sendLoop.
	resp.Answer = []dns.RR{
		{
			Name:  query.Question[0].Name,
			Type:  query.Question[0].Type,
			Class: query.Question[0].Class,
			TTL:   responseTTL,
			Data:  nil, // will be filled in below
		},
	}

	// Binary search to find the maximum payload length that does not result
	// in a wire-format message whose length exceeds the limit.
	low := 0
	high := 32768
	for low+1 < high {
		mid := (low + high) / 2
		resp.Answer[0].Data = encode(make([]byte, mid))
		buf, err := resp.WireFormat()
		if err != nil {
			panic(err)
		}
		if len(buf) <= limit {
			low = mid
		} else {
			high = mid
		}
	}

	return low
}

// computeMaxEncodedPayloadNameBased computes the maximum raw payload bytes that
// can fit in a name-based RDATA (CNAME, NS, MX, SRV). The capacity is the same
// for all name-based types because it is constrained by the 255-byte DNS name
// limit, not the UDP payload size. The MX/SRV fixed headers (2/6 bytes) add to
// the total RDATA but do not reduce the name portion.
func computeMaxEncodedPayloadNameBased(domain dns.Name) int {
	domainWireLen := 1 // null terminator
	for _, label := range domain {
		domainWireLen += 1 + len(label)
	}
	available := 255 - domainWireLen
	if available <= 0 {
		return 0
	}
	encodedBytes := available * 63 / 64
	return encodedBytes * 5 / 8
}

// computeMaxEncodedPayloadMultiRR computes the maximum raw payload bytes that
// can fit in multiple fixed-size RRs (A=4 bytes, AAAA=16 bytes) within a DNS
// response of at most limit bytes. Uses binary search like the TXT computation.
func computeMaxEncodedPayloadMultiRR(limit int, chunkSize int) int {
	maxLengthName, err := dns.NewName([][]byte{
		[]byte("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"),
		[]byte("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"),
		[]byte("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"),
		[]byte("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"),
	})
	if err != nil {
		panic(err)
	}

	queryLimit := uint16(limit)
	if int(queryLimit) != limit {
		queryLimit = 0xffff
	}
	query := &dns.Message{
		Question: []dns.Question{
			{
				Name:  maxLengthName,
				Type:  recordType,
				Class: dns.ClassIN,
			},
		},
		Additional: []dns.RR{
			{
				Name:  dns.Name{},
				Type:  dns.RRTypeOPT,
				Class: queryLimit,
				TTL:   0,
				Data:  []byte{},
			},
		},
	}
	resp, _, _ := responseFor(query, []dns.Name{})

	// Binary search: find max payload that fits when split into chunkSize RRs.
	low := 0
	high := 32768
	for low+1 < high {
		mid := (low + high) / 2
		// Simulate encoding: 2-byte length prefix + payload → ceil((2+mid)/chunkSize) RRs.
		totalBytes := 2 + mid
		numChunks := (totalBytes + chunkSize - 1) / chunkSize
		resp.Answer = make([]dns.RR, numChunks)
		for i := range numChunks {
			resp.Answer[i] = dns.RR{
				Name:  query.Question[0].Name,
				Type:  query.Question[0].Type,
				Class: query.Question[0].Class,
				TTL:   responseTTL,
				Data:  make([]byte, chunkSize),
			}
		}
		buf, err := resp.WireFormat()
		if err != nil {
			panic(err)
		}
		if len(buf) <= limit {
			low = mid
		} else {
			high = mid
		}
	}
	return low
}

func run(privkey []byte, domains []dns.Name, upstream string, dnsConn net.PacketConn, fallbackAddr *net.UDPAddr, idleTimeout time.Duration, keepAlive time.Duration, queueSize int, kcpWindowSize int, queueOverflowMode turbotunnel.QueueOverflowMode, wireConfig turbotunnel.WireConfig) error {
	defer dnsConn.Close()

	log.Infof("pubkey %x", noise.PubkeyFromPrivkey(privkey))

	// We have a variable amount of room in which to encode downstream
	// packets in each response, because each response must contain the
	// query's Question section, which is of variable length. But we cannot
	// give dynamic packet size limits to KCP; the best we can do is set a
	// global maximum which no packet will exceed. We choose that maximum to
	// keep the UDP payload size under maxUDPPayload, even in the worst case
	// of a maximum-length name in the query's Question section.
	var maxEncodedPayload int
	
	// HELPER: Find the minimum capacity across all configured domains
	getMinNameBasedCapacity := func(domainList []dns.Name) int {
		minCap := 999999
		for _, d := range domainList {
			cap := computeMaxEncodedPayloadNameBased(d)
			if cap < minCap {
				minCap = cap
			}
		}
		return minCap
	}
		
	switch recordType {
	case dns.RRTypeCNAME, dns.RRTypeNS, dns.RRTypeMX, dns.RRTypeSRV:
		maxEncodedPayload = getMinNameBasedCapacity(domains) //  Use Helper
	case dns.RRTypeA:
		maxEncodedPayload = computeMaxEncodedPayloadMultiRR(maxUDPPayload, 4)
	case dns.RRTypeAAAA:
		maxEncodedPayload = computeMaxEncodedPayloadMultiRR(maxUDPPayload, 16)
	case dns.RRTypeNULL:
		maxEncodedPayload = computeMaxEncodedPayload(maxUDPPayload, dns.EncodeRDataNULL)
	case dns.RRTypeCAA:
		maxEncodedPayload = computeMaxEncodedPayload(maxUDPPayload, dns.EncodeRDataCAA)
	default:
		maxEncodedPayload = computeMaxEncodedPayload(maxUDPPayload, dns.EncodeRDataTXT)
	}
	// 2 bytes accounts for a packet length prefix.
	mtu := maxEncodedPayload - 2
	if mtu < 80 {
		if mtu < 0 {
			mtu = 0
		}
		return fmt.Errorf("maximum UDP payload size of %d leaves only %d bytes for payload", maxUDPPayload, mtu)
	}
	log.Infof("effective MTU %d", mtu)

	// Start up the virtual PacketConn for turbotunnel.
	ttConn := turbotunnel.NewQueuePacketConn(turbotunnel.DummyAddr{}, idleTimeout*2, queueSize, queueOverflowMode)
	ln, err := kcp.ServeConn(nil, 0, 0, ttConn)
	if err != nil {
		return fmt.Errorf("opening KCP listener: %v", err)
	}
	defer ln.Close()
	go func() {
		err := acceptSessions(ln, privkey, mtu, upstream, idleTimeout, keepAlive, kcpWindowSize)
		if err != nil {
			log.Warnf("accept sessions: %v", err)
		}
	}()

	ch := make(chan *record, 100)
	defer close(ch)

	// Create a fallback manager if an address is specified.
	var fallbackMgr *FallbackManager
	if fallbackAddr != nil {
		fallbackMgr = NewFallbackManager(dnsConn, fallbackAddr)
	}

	stats := &ServerStats{}
	go func() {
		ticker := time.NewTicker(5 * time.Second)
		defer ticker.Stop()
		for range ticker.C {
			stats.log()
		}
	}()

	// We could run multiple copies of sendLoop; that would allow more time
	// for each response to collect downstream data before being evicted by
	// another response that needs to be sent.
	go func() {
		err := sendLoop(dnsConn, ttConn, ch, maxEncodedPayload)
		if err != nil {
			log.Warnf("sendLoop: %v", err)
		}
	}()

	return recvLoop(domains, dnsConn, ttConn, ch, fallbackMgr, stats, wireConfig)

}

var version = "dev"

func main() {
	var showVersion bool
	var genKey bool
	var domainArg string
	var upstream string
	var privkeyFilename string
	var privkeyString string
	var pubkeyFilename string
	var udpAddr string
	var fallbackAddrString string
	var idleTimeoutStr string
	var keepAliveStr string
	var compatDnstt bool
	var clientIDSize int
	var recordTypeStr string
	var queueSize int
	var kcpWindowSize int
	var queueOverflowStr string

	flag.Usage = func() {
		fmt.Fprintf(flag.CommandLine.Output(), `Usage:
  %[1]s -gen-key -privkey-file PRIVKEYFILE -pubkey-file PUBKEYFILE
  %[1]s -udp ADDR -privkey-file PRIVKEYFILE [-fallback FALLBACKADDR] -domain DOMAIN -upstream UPSTREAMADDR

Example:
  %[1]s -gen-key -privkey-file server.key -pubkey-file server.pub
  %[1]s -udp :53 -privkey-file server.key -domain t.example.com -upstream 127.0.0.1:8000
  %[1]s -udp :53 -privkey-file server.key -fallback 127.0.0.1:8888 -domain t.example.com -upstream 127.0.0.1:8000

`, os.Args[0])
		flag.PrintDefaults()
	}
	flag.BoolVar(&genKey, "gen-key", false, "generate a server keypair; print to stdout or save to files")
	flag.IntVar(&maxUDPPayload, "mtu", maxUDPPayload, "maximum size of DNS responses")
	flag.StringVar(&privkeyString, "privkey", "", fmt.Sprintf("server private key (%d hex digits)", noise.KeyLen*2))
	flag.StringVar(&privkeyFilename, "privkey-file", "", "read server private key from file (with -gen-key, write to file)")
	flag.StringVar(&pubkeyFilename, "pubkey-file", "", "with -gen-key, write server public key to file")
	flag.StringVar(&udpAddr, "udp", "", "UDP address to listen on (required)")
	flag.StringVar(&fallbackAddrString, "fallback", "", "UDP endpoint to forward non-DNS packets to (e.g., 127.0.0.1:8888)")
	flag.StringVar(&domainArg, "domain", "", "tunnel domain (e.g., t.example.com)")
	flag.StringVar(&upstream, "upstream", "", "TCP address to forward tunneled connections to (e.g., 127.0.0.1:8000)")
	// idle-timeout: if no data is received from a client for this long,
	// the tunnel session is considered dead and torn down. Should match
	// the client's -idle-timeout.
	flag.StringVar(&idleTimeoutStr, "idle-timeout", defaultIdleTimeout.String(), "session idle timeout (e.g. 10s, 1m); tears down sessions with no data within this period")
	// keepalive: how often smux sends keepalive pings. Must be shorter than
	// idle-timeout. Should match the client's -keepalive value.
	flag.StringVar(&keepAliveStr, "keepalive", defaultKeepAlive.String(), "keepalive ping interval (e.g. 2s, 500ms); must be less than idle-timeout")
	flag.BoolVar(&compatDnstt, "dnstt-compat", false, "use original dnstt wire format (8-byte ClientID, padding prefixes)")
	flag.IntVar(&clientIDSize, "clientid-size", 2, "client ID size in bytes (ignored when -dnstt-compat is set)")
	flag.StringVar(&recordTypeStr, "record-type", "txt", "DNS record type for downstream data (txt, null, cname, a, aaaa, mx, ns, srv, caa)")
	flag.IntVar(&queueSize, "queue-size", turbotunnel.QueueSize, "packet queue size for DNS tunnel transport")
	flag.IntVar(&kcpWindowSize, "kcp-window-size", 0, "KCP send/receive window size in packets (0 = queue-size/2)")
	flag.StringVar(&queueOverflowStr, "queue-overflow", string(turbotunnel.DefaultQueueOverflowMode), "queue overflow behavior: drop or block")

	var logLevel string
	flag.StringVar(&logLevel, "log-level", "info", "log level (debug, info, warning, error)")
	flag.BoolVar(&showVersion, "v", false, "print version and exit")
	flag.Parse()

	if showVersion {
		fmt.Println(version)
		os.Exit(0)
	}

	level, err := log.ParseLevel(logLevel)
	if err != nil {
		fmt.Fprintf(os.Stderr, "invalid log level: %s\n", logLevel)
		os.Exit(1)
	}
	log.SetLevel(level)
	log.SetFormatter(&log.TextFormatter{FullTimestamp: true, TimestampFormat: "2006-01-02 15:04:05"})

	rt, err := dns.ParseRecordType(recordTypeStr)
	if err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		os.Exit(1)
	}
	recordType = rt

	if genKey {
		// -gen-key mode.
		if flag.NArg() != 0 || privkeyString != "" || udpAddr != "" || fallbackAddrString != "" || domainArg != "" || upstream != "" || idleTimeoutStr != defaultIdleTimeout.String() || keepAliveStr != defaultKeepAlive.String() {
			flag.Usage()
			os.Exit(1)
		}
		if err := generateKeypair(privkeyFilename, pubkeyFilename); err != nil {
			fmt.Fprintf(os.Stderr, "cannot generate keypair: %v\n", err)
			os.Exit(1)
		}
	} else {
		// Ordinary server mode.
		if flag.NArg() != 0 {
			fmt.Fprintf(os.Stderr, "unexpected positional arguments\n")
			flag.Usage()
			os.Exit(1)
		}
		if domainArg == "" {
			fmt.Fprintf(os.Stderr, "the -domain option is required\n")
			os.Exit(1)
		}
		if upstream == "" {
			fmt.Fprintf(os.Stderr, "the -upstream option is required\n")
			os.Exit(1)
		}

		var domains []dns.Name
		for _, dStr := range strings.Split(domainArg, ",") {
			dStr = strings.TrimSpace(dStr)
			if dStr == "" {
				continue
			}
			d, err := dns.ParseName(dStr)
			if err != nil {
				fmt.Fprintf(os.Stderr, "invalid domain %+q: %v\n", dStr, err)
				os.Exit(1)
			}
			domains = append(domains, d)
		}
		if len(domains) == 0 {
			fmt.Fprintf(os.Stderr, "no valid domains provided\n")
			os.Exit(1)
		}

		log.Infof("serving domains: %v", domains) // Log all active domains
		
		// We keep upstream as a string in order to eventually pass it
		// to net.Dial in handleStream. But for the sake of displaying
		// an error or warning at startup, rather than only when the
		// first stream occurs, we apply some parsing and name
		// resolution checks here.
		{
			upstreamHost, _, err := net.SplitHostPort(upstream)
			if err != nil {
				// host:port format is required in all cases, so
				// this is a fatal error.
				fmt.Fprintf(os.Stderr, "cannot parse upstream address %+q: %v\n", upstream, err)
				os.Exit(1)
			}
			upstreamIPAddr, err := net.ResolveIPAddr("ip", upstreamHost)
			if err != nil {
				// Failure to resolve the host portion is only a
				// warning. The name will be re-resolved on each
				// net.Dial in handleStream.
				log.Warnf("cannot resolve upstream host %+q: %v", upstreamHost, err)
			} else if upstreamIPAddr.IP == nil {
				// Handle the special case of an empty string
				// for the host portion, which resolves to a nil
				// IP. This is a fatal error as we will not be
				// able to dial this address.
				fmt.Fprintf(os.Stderr, "cannot parse upstream address %+q: missing host in address\n", upstream)
				os.Exit(1)
			}
		}

		if udpAddr == "" {
			fmt.Fprintf(os.Stderr, "the -udp option is required\n")
			os.Exit(1)
		}
		dnsConn, err := net.ListenPacket("udp", udpAddr)
		if err != nil {
			fmt.Fprintf(os.Stderr, "opening UDP listener: %v\n", err)
			os.Exit(1)
		}

		var fallbackAddr *net.UDPAddr
		if fallbackAddrString != "" {
			fallbackAddr, err = net.ResolveUDPAddr("udp", fallbackAddrString)
			if err != nil {
				fmt.Fprintf(os.Stderr, "cannot resolve fallback address %+q: %v\n", fallbackAddrString, err)
				os.Exit(1)
			}
		}

		if pubkeyFilename != "" {
			fmt.Fprintf(os.Stderr, "-pubkey-file may only be used with -gen-key\n")
			os.Exit(1)
		}

		var privkey []byte
		if privkeyFilename != "" && privkeyString != "" {
			fmt.Fprintf(os.Stderr, "only one of -privkey and -privkey-file may be used\n")
			os.Exit(1)
		} else if privkeyFilename != "" {
			var err error
			privkey, err = readKeyFromFile(privkeyFilename)
			if err != nil {
				fmt.Fprintf(os.Stderr, "cannot read privkey from file: %v\n", err)
				os.Exit(1)
			}
		} else if privkeyString != "" {
			var err error
			privkey, err = noise.DecodeKey(privkeyString)
			if err != nil {
				fmt.Fprintf(os.Stderr, "privkey format error: %v\n", err)
				os.Exit(1)
			}
		}
		if len(privkey) == 0 {
			log.Warnf("generating a temporary one-time keypair")
			log.Infof("use the -privkey or -privkey-file option for a persistent server keypair")
			var err error
			privkey, err = noise.GeneratePrivkey()
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
				os.Exit(1)
			}
		}

		idleTimeout, err := time.ParseDuration(idleTimeoutStr)
		if err != nil {
			fmt.Fprintf(os.Stderr, "invalid -idle-timeout: %v\n", err)
			os.Exit(1)
		}
		keepAlive, err := time.ParseDuration(keepAliveStr)
		if err != nil {
			fmt.Fprintf(os.Stderr, "invalid -keepalive: %v\n", err)
			os.Exit(1)
		}
		if keepAlive >= idleTimeout {
			fmt.Fprintf(os.Stderr, "-keepalive (%s) must be less than -idle-timeout (%s)\n", keepAlive, idleTimeout)
			os.Exit(1)
		}
		if queueSize < 32 {
			fmt.Fprintf(os.Stderr, "-queue-size (%d) must be at least 32\n", queueSize)
			os.Exit(1)
		}
		if kcpWindowSize < 0 {
			fmt.Fprintf(os.Stderr, "-kcp-window-size (%d) must be >= 0\n", kcpWindowSize)
			os.Exit(1)
		}
		if kcpWindowSize == 0 {
			kcpWindowSize = queueSize / 2
			if kcpWindowSize < 1 {
				kcpWindowSize = 1
			}
		}
		if kcpWindowSize > queueSize {
			fmt.Fprintf(os.Stderr, "-kcp-window-size (%d) must be <= -queue-size (%d)\n", kcpWindowSize, queueSize)
			os.Exit(1)
		}
		queueOverflowMode, err := turbotunnel.ParseQueueOverflowMode(queueOverflowStr)
		if err != nil {
			fmt.Fprintf(os.Stderr, "invalid -queue-overflow: %v\n", err)
			os.Exit(1)
		}
		log.Infof("transport config: queue-size=%d kcp-window-size=%d queue-overflow=%s", queueSize, kcpWindowSize, queueOverflowMode)

		var wireConfig turbotunnel.WireConfig
		if compatDnstt {
			if recordType != dns.RRTypeTXT {
				log.Warnf("-dnstt-compat forces record-type to txt; ignoring -record-type %s", recordTypeStr)
				recordType = dns.RRTypeTXT
			}
			wireConfig = turbotunnel.WireConfig{ClientIDSize: 8, Compat: true}
			// Override vaydns defaults with dnstt-compatible values unless
			// the user explicitly set them.
			explicitFlags := make(map[string]bool)
			flag.Visit(func(f *flag.Flag) {
				explicitFlags[f.Name] = true
			})
			if !explicitFlags["idle-timeout"] {
				idleTimeout = 2 * time.Minute
			}
			if !explicitFlags["keepalive"] {
				keepAlive = 10 * time.Second
			}
			// Re-validate after overrides.
			if keepAlive >= idleTimeout {
				fmt.Fprintf(os.Stderr, "-keepalive (%s) must be less than -idle-timeout (%s)\n", keepAlive, idleTimeout)
				os.Exit(1)
			}
		} else {
			if clientIDSize <= 0 {
				fmt.Fprintf(os.Stderr, "-clientid-size must be positive\n")
				os.Exit(1)
			}
			wireConfig = turbotunnel.WireConfig{ClientIDSize: clientIDSize}
		}
		log.Infof("wire config: clientid-size=%d compat=%v", wireConfig.ClientIDSize, wireConfig.Compat)

		switch recordType {
		case dns.RRTypeCNAME, dns.RRTypeNS, dns.RRTypeMX, dns.RRTypeSRV:
			explicitFlags := make(map[string]bool)
			flag.Visit(func(f *flag.Flag) {
				explicitFlags[f.Name] = true
			})
			if explicitFlags["mtu"] {
				log.Warnf("-mtu has no effect with -record-type %s; capacity is bounded by the DNS name length limit (255 bytes)", recordTypeStr)
			}
		}

		err = run(privkey, domains, upstream, dnsConn, fallbackAddr, idleTimeout, keepAlive, queueSize, kcpWindowSize, queueOverflowMode, wireConfig)
		if err != nil {
			log.Fatalf("%v", err)
		}
	}
}
