package client

import (
	"bufio"
	"context"
	"encoding/binary"
	"io"
	log "github.com/sirupsen/logrus"
	"net"
	"sync"
	"time"

	"github.com/net2share/vaydns/turbotunnel"
)

const dialTimeout = 30 * time.Second

// TLSPacketConn is a TLS- and TCP-based transport for DNS messages, used for
// DNS over TLS (DoT). Its WriteTo and ReadFrom methods exchange DNS messages
// over a TLS channel, prefixing each message with a two-octet length field as
// in DNS over TCP.
//
// TLSPacketConn deals only with already formatted DNS messages. It does not
// handle encoding information into the messages. That is rather the
// responsibility of DNSPacketConn.
//
// https://tools.ietf.org/html/rfc7858
type TLSPacketConn struct {
	// QueuePacketConn is the direct receiver of ReadFrom and WriteTo calls.
	// recvLoop and sendLoop take the messages out of the receive and send
	// queues and actually put them on the network.
	*turbotunnel.QueuePacketConn
	connMu sync.Mutex
	conn   net.Conn
}

// NewTLSPacketConn creates a new TLSPacketConn configured to use the TLS
// server at addr as a DNS over TLS resolver. It maintains a TLS connection to
// the resolver, reconnecting as necessary. It closes the connection if any
// reconnection attempt fails.
func NewTLSPacketConn(addr string, dialTLSContext func(ctx context.Context, network, addr string) (net.Conn, error), queueSize int, overflowMode turbotunnel.QueueOverflowMode) (*TLSPacketConn, error) {
	dial := func() (net.Conn, error) {
		ctx, cancel := context.WithTimeout(context.Background(), dialTimeout)
		defer cancel()
		return dialTLSContext(ctx, "tcp", addr)
	}
	// We maintain one TLS connection at a time, redialing it whenever it
	// becomes disconnected. We do the first dial here, outside the
	// goroutine, so that any immediate and permanent connection errors are
	// reported directly to the caller of NewTLSPacketConn.
	conn, err := dial()
	if err != nil {
		return nil, err
	}
	c := &TLSPacketConn{
		QueuePacketConn: turbotunnel.NewQueuePacketConn(turbotunnel.DummyAddr{}, 0, queueSize, overflowMode),
	}
	c.setConn(conn)
	go func() {
		defer c.Close()
		for {
			var wg sync.WaitGroup
			wg.Add(2)
			go func() {
				err := c.recvLoop(conn)
				if err != nil {
					log.Errorf("recvLoop: %v", err)
				}
				wg.Done()
			}()
			go func() {
				err := c.sendLoop(conn)
				if err != nil {
					log.Errorf("sendLoop: %v", err)
				}
				wg.Done()
			}()
			wg.Wait()
			c.clearConn(conn)
			conn.Close()

			select {
			case <-c.Closed():
				return
			default:
			}

			// Whenever the TLS connection dies, redial a new one.
			conn, err = dial()
			if err != nil {
				log.Errorf("dial tls: %v", err)
				break
			}

			select {
			case <-c.Closed():
				conn.Close()
				return
			default:
			}
			c.setConn(conn)
		}
	}()
	return c, nil
}

func (c *TLSPacketConn) setConn(conn net.Conn) {
	c.connMu.Lock()
	c.conn = conn
	c.connMu.Unlock()
}

func (c *TLSPacketConn) clearConn(conn net.Conn) {
	c.connMu.Lock()
	if c.conn == conn {
		c.conn = nil
	}
	c.connMu.Unlock()
}

func (c *TLSPacketConn) closeActiveConn() {
	c.connMu.Lock()
	conn := c.conn
	c.conn = nil
	c.connMu.Unlock()
	if conn != nil {
		conn.Close()
	}
}

// Close tears down both the packet queue and any active TLS connection,
// ensuring the reconnect goroutine exits.
func (c *TLSPacketConn) Close() error {
	c.closeActiveConn()
	return c.QueuePacketConn.Close()
}

// recvLoop reads length-prefixed messages from conn and passes them to the
// incoming queue.
func (c *TLSPacketConn) recvLoop(conn net.Conn) error {
	br := bufio.NewReader(conn)
	for {
		var length uint16
		err := binary.Read(br, binary.BigEndian, &length)
		if err != nil {
			if err == io.EOF {
				err = nil
			}
			return err
		}
		p := make([]byte, int(length))
		_, err = io.ReadFull(br, p)
		if err != nil {
			return err
		}
		c.QueuePacketConn.QueueIncoming(p, turbotunnel.DummyAddr{})
	}
}

// sendLoop reads messages from the outgoing queue and writes them,
// length-prefixed, to conn.
func (c *TLSPacketConn) sendLoop(conn net.Conn) error {
	bw := bufio.NewWriterSize(conn, 16384)
	outgoing := c.QueuePacketConn.OutgoingQueue(turbotunnel.DummyAddr{})
	closed := c.QueuePacketConn.Closed()

	for {
		var p []byte
		select {
		case <-closed:
			return nil
		case p = <-outgoing:
		}

		length := uint16(len(p))
		if int(length) != len(p) {
			panic(len(p))
		}
		if err := binary.Write(bw, binary.BigEndian, &length); err != nil {
			return err
		}
		if _, err := bw.Write(p); err != nil {
			return err
		}

		// Limited safe drain (max 8 packets per flush) + error checking
		const maxDrain = 8
		drained := 0
	drain:
		for drained < maxDrain {
			select {
			case p2 := <-outgoing:
				length2 := uint16(len(p2))
				if err := binary.Write(bw, binary.BigEndian, &length2); err != nil {
					return err
				}
				if _, err := bw.Write(p2); err != nil {
					return err
				}
				drained++
			default:
				break drain
			}
		}

		if err := bw.Flush(); err != nil {
			return err
		}
	}
}

