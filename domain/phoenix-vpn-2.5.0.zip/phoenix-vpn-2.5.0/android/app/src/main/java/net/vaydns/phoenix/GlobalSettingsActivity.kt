package net.vaydns.phoenix

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.google.android.material.appbar.MaterialToolbar
import mobile.Mobile

class GlobalSettingsActivity : AppCompatActivity() {

    private lateinit var cbDefaultAtStart: SwitchCompat
    private lateinit var rgTunnelMode: android.widget.RadioGroup

    // Menu Toggles
    private lateinit var cbUseLayer7Ping: SwitchCompat
    private lateinit var cbUpdateConfigs: SwitchCompat
    private lateinit var cbUpdateResolvers: SwitchCompat
    private lateinit var cbUploadConfigs: SwitchCompat
    private lateinit var cbUploadResolvers: SwitchCompat
    private lateinit var cbImportResolvers: SwitchCompat
    private lateinit var cbExportResolvers: SwitchCompat
    private lateinit var cbShowShareLogs: SwitchCompat
    private lateinit var cbShowDebugLogging: SwitchCompat

    // Global VLESS Fallback IP (Still relevant for scanner)
    private lateinit var btnCfHistory: android.widget.ImageButton
    private lateinit var rgEngineMode: android.widget.RadioGroup
    private lateinit var cbGlobalProtocolOverride: SwitchCompat
    private lateinit var spinnerGlobalProtocol: android.widget.Spinner
    private lateinit var layoutCdn: View
    private lateinit var spinnerCdn: android.widget.Spinner
    private lateinit var cbDebugLogs: SwitchCompat
    //private val supportedProtocols = listOf("vaydns", "hysteria2", "reality-tcp",  "reality-xhttp", "vless-ws", "vless-httpupgrade", "vless-grpc", "vless-xhttp")
    private val supportedProtocols = listOf("vaydns", "hysteria2", "reality-tcp",  "reality-xhttp", "vless-ws", "vless-httpupgrade", "vless-xhttp")
    // Notification Management
    private lateinit var etUnlockedDelay: EditText
    private lateinit var etLockedDelay: EditText
    private lateinit var etNotifUpdate: EditText
    private lateinit var etVaydnsMtu: EditText
    private lateinit var tvGlobalProtocolHeader: TextView
    private lateinit var divProtocolModeDivider: View
    private lateinit var tvStartupBehaviorHeader: TextView
    private lateinit var divStartupModeDivider: View
    private lateinit var cbUseFragmentation: SwitchCompat
    private lateinit var cbBlockQuic: SwitchCompat
    // private lateinit var tvProtocolModeLabel: TextView
    private lateinit var etGlobalDnsServer: EditText
    private lateinit var rgTunnelApps: android.widget.RadioGroup
    private lateinit var tvAllAppsWarning: TextView
    private lateinit var cbTunnelAndroidServices: SwitchCompat
    private lateinit var cbImportApps: SwitchCompat
    private lateinit var cbExportApps: SwitchCompat
    private lateinit var cbShowBackupRestore: SwitchCompat
    private lateinit var cbGetServerIpFromDomain: SwitchCompat

    private lateinit var cbUseSniPool: SwitchCompat
    private lateinit var spinnerSniPool: android.widget.Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_global_settings)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar_global_settings)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // 1. Intercept toolbar back click
        toolbar.setNavigationOnClickListener { checkIpAndExit() }

        // 2. Intercept system hardware back press / swipe gestures
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                checkIpAndExit()
            }
        })

        // Bind UI Elements
        cbDefaultAtStart = findViewById(R.id.cb_default_configs_at_start)
        rgTunnelMode = findViewById(R.id.rg_tunnel_mode)

        cbUseLayer7Ping = findViewById(R.id.cb_use_layer7_ping)
        cbUpdateConfigs = findViewById(R.id.cb_show_update_configs)
        cbUpdateResolvers = findViewById(R.id.cb_show_update_resolvers)
        cbUploadConfigs = findViewById(R.id.cb_show_upload_configs)
        cbUploadResolvers = findViewById(R.id.cb_show_upload_resolvers)
        cbImportResolvers = findViewById(R.id.cb_show_import_resolvers)
        cbExportResolvers = findViewById(R.id.cb_show_export_resolvers)
        cbShowShareLogs = findViewById(R.id.cb_show_share_logs)
        cbShowDebugLogging = findViewById(R.id.cb_show_debug_logging)

        btnCfHistory = findViewById(R.id.btn_cf_history)
        rgEngineMode = findViewById(R.id.rg_engine_mode)
        cbUseFragmentation = findViewById(R.id.cb_use_fragmentation)
        cbBlockQuic = findViewById(R.id.cb_block_quic)

        cbImportApps = findViewById(R.id.cb_show_import_apps)
        cbExportApps = findViewById(R.id.cb_show_export_apps)
        cbShowBackupRestore = findViewById(R.id.cb_show_backup_restore)
        cbGetServerIpFromDomain = findViewById(R.id.cb_get_server_ip_from_domain)

        // Bind Override UI
        cbGlobalProtocolOverride = findViewById(R.id.cb_global_protocol_override)
        btnCfHistory.setOnClickListener {
            // 1. Grab the currently selected CDN on the screen
            val selectedCdn = spinnerCdn.selectedItem?.toString() ?: "CloudX"

            // 2. Save it immediately so it doesn't get lost if the system kills the activity
            getSharedPreferences("TunnelSettingsPrefs", Context.MODE_PRIVATE)
                .edit().putString("selected_cdn", selectedCdn).apply()

            // 3. Launch the Manager and tell it which CDN to display
            val intent = Intent(this, CdnIpManagerActivity::class.java).apply {
                putExtra("TARGET_CDN", selectedCdn)
            }
            startActivity(intent)
        }

        rgTunnelApps = findViewById(R.id.rg_tunnel_apps)
        tvAllAppsWarning = findViewById(R.id.tv_all_apps_warning)
        cbTunnelAndroidServices = findViewById(R.id.cb_tunnel_android_services)

        rgTunnelApps.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId == R.id.rb_apps_all) {
                tvAllAppsWarning.visibility = View.VISIBLE
            } else {
                tvAllAppsWarning.visibility = View.GONE
            }
        }

        cbUseSniPool = findViewById(R.id.cb_use_sni_pool)
        spinnerSniPool = findViewById(R.id.spinner_sni_pool)

        cbUseSniPool.setOnCheckedChangeListener { _, isChecked ->
            spinnerSniPool.visibility = if (isChecked) View.VISIBLE else View.GONE
        }

        spinnerGlobalProtocol = findViewById(R.id.spinner_global_protocol)
        etGlobalDnsServer = findViewById(R.id.et_global_dns_server)

        layoutCdn = findViewById(R.id.layout_cdn)
        spinnerCdn = findViewById(R.id.spinner_cdn)
// 1. Show an educational warning if they try to tap/type in the box
        etGlobalDnsServer.setOnClickListener {
            Toast.makeText(this, "Manual entry disabled to prevent DNS leaks. Please use the Global DNS Scanner to assign a secure DoH server.", Toast.LENGTH_LONG).show()
        }

        // 2. Allow users to clear the assigned DNS if they long-press it
        etGlobalDnsServer.setOnLongClickListener {
            com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle("Clear Global DNS")
                .setMessage("Do you want to clear the Global DNS Server and disable DoH domain resolution?")
                .setPositiveButton("Disable") { _, _ ->

                    // Visually set it to your sentinel value
                    etGlobalDnsServer.setText("0.0.0.0")

                    Toast.makeText(this, "DoH Resolution Disabled", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
            true
        }
        // Populate the Spinner

        val tpAdapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_item, supportedProtocols)
        tpAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerGlobalProtocol.adapter = tpAdapter

        cbGlobalProtocolOverride.setOnCheckedChangeListener { _, isChecked ->
            spinnerGlobalProtocol.visibility = if (isChecked) View.VISIBLE else View.GONE
        }
        // NOTE: rgProtocolMode has been permanently removed!

        etUnlockedDelay = findViewById(R.id.et_unlocked_delay)
        etLockedDelay = findViewById(R.id.et_locked_delay)
        etNotifUpdate = findViewById(R.id.et_notif_update)
        etVaydnsMtu = findViewById(R.id.et_vaydns_mtu)

        tvGlobalProtocolHeader = findViewById(R.id.tv_global_protocol_header)
        divProtocolModeDivider = findViewById(R.id.div_protocol_mode_divider)
        tvStartupBehaviorHeader = findViewById(R.id.tv_startup_behavior_header)
        divStartupModeDivider = findViewById(R.id.div_startup_mode_divider)
        // tvProtocolModeLabel = findViewById(R.id.tv_protocol_mode_label)

        // 1. Link the UI element
        cbDebugLogs = findViewById(R.id.cb_debug_logs)

        // 2. Load the saved preference
        val sharedPrefs = getSharedPreferences("PhoenixVpnPrefs", Context.MODE_PRIVATE)
        cbDebugLogs.isChecked = sharedPrefs.getBoolean("debug_logs_enabled", false)

        // 3. Save when toggled
        cbDebugLogs.setOnCheckedChangeListener { _, isChecked ->
            sharedPrefs.edit().putBoolean("debug_logs_enabled", isChecked).apply()
        }

        val sniCount = Mobile.getSniPoolCount()
        val sniList = mutableListOf<String>()
        for (i in 1..sniCount) {
            sniList.add("SNI-$i")
        }
        val sniAdapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_item, sniList)
        sniAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerSniPool.adapter = sniAdapter

        // Populate CDN Spinner dynamically from Go Native Vault
        val cdnList = mutableListOf<String>()
        val cdnCount = Mobile.getCdnCount()
        for (i in 0 until cdnCount) {
            val name = Mobile.getCdnName(i)
            if (name.isNotEmpty()) {
                cdnList.add(name)
            }
        }
        // Fallback options if JSON hasn't loaded yet
        if (cdnList.isEmpty()) {
            cdnList.add("CloudX")
            cdnList.add("CloudY")
            cdnList.add("CloudZ")
        }

        val cdnAdapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_item, cdnList)
        cdnAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCdn.adapter = cdnAdapter

        loadSettings()
    }

    private fun loadSettings() {
        val appPrefs = getSharedPreferences("PhoenixVpnPrefs", Context.MODE_PRIVATE)
        val menuPrefs = getSharedPreferences("MenuSettings", Context.MODE_PRIVATE)
        val tunnelPrefs = getSharedPreferences("TunnelSettingsPrefs", Context.MODE_PRIVATE)

        val useSniPool = tunnelPrefs.getBoolean("use_sni_pool", false)
        val sniIndex = tunnelPrefs.getInt("selected_sni_index", 0)

        cbImportApps.isChecked = menuPrefs.getBoolean("show_import_apps", false)
        cbExportApps.isChecked = menuPrefs.getBoolean("show_export_apps", false)

        etUnlockedDelay.setText(appPrefs.getLong("unlocked_delay_ms", 2000L).toString())
        etLockedDelay.setText(appPrefs.getLong("locked_delay_ms", 5000L).toString())
        etNotifUpdate.setText(appPrefs.getLong("notif_update_ms", 4000L).toString())
        etVaydnsMtu.setText(appPrefs.getLong("global_vaydns_mtu", 0L).toString())
        etGlobalDnsServer.setText(tunnelPrefs.getString("global_dns_server", ""))


        // Load Startup Preferences
        cbDefaultAtStart.isChecked = appPrefs.getBoolean("default_configs_at_start", true)
        val isVpnMode = appPrefs.getBoolean("default_to_vpn_mode", true)
        if (isVpnMode) {
            rgTunnelMode.check(R.id.rb_mode_vpn)
        } else {
            rgTunnelMode.check(R.id.rb_mode_proxy)
        }

        val tunnelAllApps = appPrefs.getBoolean("tunnel_all_apps", false)
        if (tunnelAllApps) {
            rgTunnelApps.check(R.id.rb_apps_all)
            tvAllAppsWarning.visibility = View.VISIBLE
        } else {
            rgTunnelApps.check(R.id.rb_apps_selected)
            tvAllAppsWarning.visibility = View.GONE
        }

        cbTunnelAndroidServices.isChecked = appPrefs.getBoolean("tunnel_android_services", false)
        // Load Menu Toggles
        cbUseLayer7Ping.isChecked = tunnelPrefs.getBoolean("use_layer7_ping", true)
        cbUpdateConfigs.isChecked = menuPrefs.getBoolean("show_update_configs", false)
        cbUpdateResolvers.isChecked = menuPrefs.getBoolean("show_update_resolvers", false)
        cbUploadConfigs.isChecked = menuPrefs.getBoolean("show_upload_configs", false)
        cbUploadResolvers.isChecked = menuPrefs.getBoolean("show_upload_resolvers", false)
        cbImportResolvers.isChecked = menuPrefs.getBoolean("show_import_resolvers", false)
        cbExportResolvers.isChecked = menuPrefs.getBoolean("show_export_resolvers", false)
        cbShowBackupRestore.isChecked = menuPrefs.getBoolean("show_backup_restore", false)
        cbShowShareLogs.isChecked = menuPrefs.getBoolean("show_share_logs", false)
        cbShowDebugLogging.isChecked = menuPrefs.getBoolean("show_debug_logging", false)
        cbUseFragmentation.isChecked = tunnelPrefs.getBoolean("use_fragmentation", false)
        cbBlockQuic.isChecked = tunnelPrefs.getBoolean("block_quic", true)
        cbGetServerIpFromDomain.isChecked = tunnelPrefs.getBoolean("get_server_ip_from_domain", false)

        // Load VLESS IP Fallback
        //etVlessWsIp.setText(tunnelPrefs.getString("vless_ws_ip", ""))
        val engineType = tunnelPrefs.getString("tun_engine", "xray")
        if (engineType == "xray") {
            rgEngineMode.check(R.id.rb_engine_xray)
        } else {
            rgEngineMode.check(R.id.rb_engine_singbox)
        }

        // Load Global Protocol Override
        val isOverride = tunnelPrefs.getBoolean("global_protocol_override", false)
        val globalProtocol = tunnelPrefs.getString("global_protocol_selected", "vaydns") ?: "vaydns"
        cbGlobalProtocolOverride.isChecked = isOverride
        spinnerGlobalProtocol.visibility = if (isOverride) View.VISIBLE else View.GONE
        val pIndex = supportedProtocols.indexOf(globalProtocol)
        if (pIndex >= 0) spinnerGlobalProtocol.setSelection(pIndex)

        // Load saved CDN Selection
        val savedCdn = tunnelPrefs.getString("selected_cdn", "CloudX") ?: "CloudX"
        for (i in 0 until spinnerCdn.adapter.count) {
            if (spinnerCdn.adapter.getItem(i).toString() == savedCdn) {
                spinnerCdn.setSelection(i)
                break
            }
        }

        cbUseSniPool.isChecked = useSniPool
        spinnerSniPool.visibility = if (useSniPool) View.VISIBLE else View.GONE
        if (sniIndex >= 0 && sniIndex < (spinnerSniPool.adapter?.count ?: 0)) {
            spinnerSniPool.setSelection(sniIndex)
        }

        // --- DYNAMIC UI VISIBILITY (Community vs Official Builds) ---
        // val isOfficialBuild = Mobile.isOfficialBuild()
        // val configCount = Mobile.getDefaultConfigCount()

        val releaseType = try { Mobile.getReleaseType().lowercase() } catch (e: Exception) { "community" }
        val configCount = Mobile.getDefaultConfigCount()

        if (releaseType == "community") {

            // 2. Hide the wrapped sections for Community Builds (Engine, Reality, Layer 7, Override, CDN, DNS)
            findViewById<View>(R.id.section_engine_mode)?.visibility = View.GONE
            findViewById<View>(R.id.section_advanced_protocols)?.visibility = View.GONE

            // 3. Remove Update & Upload options from the Menu Visibility Section
            cbUpdateConfigs.visibility = View.GONE
            cbUpdateResolvers.visibility = View.GONE
            cbUploadConfigs.visibility = View.GONE
            cbUploadResolvers.visibility = View.GONE

            // Note: SNI Pool and CloudX IP fields are automatically hidden
            // because they are now safely inside the section_advanced_protocols wrapper!

        } else if (configCount == 0L) {
            // Fallback for Private Builds that haven't downloaded configs yet
            cbDefaultAtStart.visibility = View.GONE
            cbUpdateConfigs.visibility = View.GONE
            cbUpdateResolvers.visibility = View.GONE
        }

    }

    private fun checkIpAndExit() {
        val tunnelPrefs = getSharedPreferences("TunnelSettingsPrefs", Context.MODE_PRIVATE)
        val appPrefs = getSharedPreferences("PhoenixVpnPrefs", Context.MODE_PRIVATE)
        val menuPrefs = getSharedPreferences("MenuSettings", Context.MODE_PRIVATE)
        val selectedCdn = spinnerCdn.selectedItem?.toString() ?: "CloudX"

        val useSniPool = cbUseSniPool.isChecked
        val selectedSniIndex = if (useSniPool) spinnerSniPool.selectedItemPosition else -1

        val selectedEngine = if (rgEngineMode.checkedRadioButtonId == R.id.rb_engine_xray) {
            "xray"
        } else {
            "sing-box"
        }

        // Extract Global Protocol Override states
        val overrideChecked = cbGlobalProtocolOverride.isChecked
        val selectedGlobalProto = spinnerGlobalProtocol.selectedItem?.toString() ?: "vaydns"
        val globalDns = etGlobalDnsServer.text.toString().trim()

        if (overrideChecked && selectedGlobalProto.lowercase() in listOf("vless-ws", "vless-grpc", "vless-httpupgrade", "vless-xhttp")) {
            val supported = Mobile.cdnSupportsProtocol(selectedCdn, selectedGlobalProto)
            if (!supported) {
                com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                    .setTitle("Protocol Conflict / تداخل پروتکل")
                    .setMessage("Cannot save settings: The selected CDN '$selectedCdn' does not support the '$selectedGlobalProto' protocol.\n\nPlease select a different CDN or Protocol.\n\nامکان ذخیره وجود ندارد: شبکه '$selectedCdn' از پروتکل '$selectedGlobalProto' پشتیبانی نمی‌کند. لطفاً CDN یا پروتکل خود را تغییر دهید.")
                    .setPositiveButton("OK", null)
                    .show()
                return // Instantly abort saving and prevent exiting the window
            }
        }

        tunnelPrefs.edit().apply {
            // putString("vless_ws_ip", ip)
            putString("tun_engine", selectedEngine)
            putBoolean("global_protocol_override", overrideChecked)
            putString("global_protocol_selected", selectedGlobalProto)
            putBoolean("use_layer7_ping", cbUseLayer7Ping.isChecked)
            putBoolean("use_fragmentation", cbUseFragmentation.isChecked)
            putBoolean("block_quic", cbBlockQuic.isChecked)
            putBoolean("get_server_ip_from_domain", cbGetServerIpFromDomain.isChecked)
            putString("global_dns_server", globalDns)
            putString("selected_cdn", selectedCdn)
            putBoolean("use_sni_pool", useSniPool)
            putInt("selected_sni_index", selectedSniIndex)
        }.apply()

        var unlockedDelay = etUnlockedDelay.text.toString().toLongOrNull() ?: 2000L
        var lockedDelay = etLockedDelay.text.toString().toLongOrNull() ?: 5000L
        var notifUpdate = etNotifUpdate.text.toString().toLongOrNull() ?: 4000L

        // Constraint 1: All values must be between 1000 and 10000
        unlockedDelay = unlockedDelay.coerceIn(1000L, 10000L)
        lockedDelay = lockedDelay.coerceIn(1000L, 10000L)
        notifUpdate = notifUpdate.coerceIn(1000L, 10000L)

        // Constraint 2: Locked State must be >= Unlocked State
        if (lockedDelay < unlockedDelay) lockedDelay = unlockedDelay

        // Constraint 3: Notification Update must be >= Unlocked State
        if (notifUpdate < unlockedDelay) notifUpdate = unlockedDelay

        // 2. Save App Preferences
        appPrefs.edit().apply {
            val isVpnSelected = rgTunnelMode.checkedRadioButtonId == R.id.rb_mode_vpn
            putBoolean("default_to_vpn_mode", isVpnSelected)
            putBoolean("default_configs_at_start", cbDefaultAtStart.isChecked)
            putLong("unlocked_delay_ms", unlockedDelay)
            putLong("locked_delay_ms", lockedDelay)
            putLong("notif_update_ms", notifUpdate)
            val isAllApps = rgTunnelApps.checkedRadioButtonId == R.id.rb_apps_all
            putBoolean("tunnel_all_apps", isAllApps)
            putBoolean("tunnel_android_services", cbTunnelAndroidServices.isChecked)
        }.apply()

        // 3. Save Menu Preferences
        // val isOfficialBuild = Mobile.isOfficialBuild()
        val configCount = Mobile.getDefaultConfigCount()

        menuPrefs.edit().apply {
            putBoolean("show_share_logs", cbShowShareLogs.isChecked)
            putBoolean("show_debug_logging", cbShowDebugLogging.isChecked)
            if (configCount > 0L) {
                putBoolean("show_update_configs", cbUpdateConfigs.isChecked)
                putBoolean("show_update_resolvers", cbUpdateResolvers.isChecked)
                putBoolean("show_upload_configs", cbUploadConfigs.isChecked)
                putBoolean("show_upload_resolvers", cbUploadResolvers.isChecked)
                putBoolean("show_import_resolvers", cbImportResolvers.isChecked)
                putBoolean("show_export_resolvers", cbExportResolvers.isChecked)
                putBoolean("show_import_apps", cbImportApps.isChecked)
                putBoolean("show_export_apps", cbExportApps.isChecked)
                putBoolean("show_backup_restore", cbShowBackupRestore.isChecked)
            }
            // if (isOfficialBuild) {
            //    putBoolean("show_check_app_update", cbUpdateApp.isChecked)
            // }
        }.apply()

        var enteredMtu = etVaydnsMtu.text.toString().toLongOrNull() ?: 0L
        if (enteredMtu != 0L) {
            enteredMtu = enteredMtu.coerceIn(30L, 130L)
        }

        val oldMtu = appPrefs.getLong("global_vaydns_mtu", 0L)

        // Only run the heavy bulk-update loop if the user actually changed the number
        if (enteredMtu != oldMtu) {
            appPrefs.edit().putLong("global_vaydns_mtu", enteredMtu).apply()

            try {
                // 1. Bulk update all User Configs
                val currentConfigs = net.vaydns.phoenix.ConfigEditorActivity.loadAllConfigs(this).toMutableList()
                for (i in currentConfigs.indices) {
                    currentConfigs[i] = currentConfigs[i].copy(mtu = enteredMtu)
                }
                net.vaydns.phoenix.ConfigEditorActivity.saveAllConfigs(this, currentConfigs)

                // 2. Bulk update all Default Official Configs (via their override memories)
                val defPrefs = getSharedPreferences("DefaultOverrides", Context.MODE_PRIVATE).edit()
                val officialConfigCount = Mobile.getDefaultConfigCount()
                for (i in 0 until officialConfigCount) {
                    defPrefs.putLong("default_${i}_mtu", enteredMtu)
                }
                defPrefs.apply()

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Close the activity
        finish()
    }
}